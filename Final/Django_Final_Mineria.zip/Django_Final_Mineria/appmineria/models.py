from django.db import models

# Create your models here.

class Persona(models.Model):
    grupo=models.IntegerField(default=0)
    miembro=models.IntegerField(default=0)
    cryo= models.BooleanField(default=False)
    room_num=models.IntegerField(default=0)
    edad=models.IntegerField(default=0)
    vip= models.BooleanField(default=False)
    room_serv=models.FloatField(default=0.0)
    food_court=models.FloatField(default=0.0)
    shopping=models.FloatField(default=0.0)
    spa=models.FloatField(default=0.0)
    vrd=models.FloatField(default=0.0)
    gastos=models.FloatField(default=0.0)
    B=models.IntegerField(default=0)
    C=models.IntegerField(default=0)
    D=models.IntegerField(default=0)
    E=models.IntegerField(default=0)
    F=models.IntegerField(default=0)
    G=models.IntegerField(default=0)
    T=models.IntegerField(default=0)
    PSO=models.IntegerField(default=0)
    TRAPP=models.IntegerField(default=0)
    EUROPA=models.IntegerField(default=0)
    MARS=models.IntegerField(default=0)
    Transported=models.BooleanField(default=False)


