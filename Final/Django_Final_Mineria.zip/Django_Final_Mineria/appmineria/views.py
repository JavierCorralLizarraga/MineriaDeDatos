from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from django.template import loader
from sqlalchemy import null
import pandas as pd
import pickle


from appmineria.models import Persona

# Create your views here.


#Con template

def index(request):
    template = loader.get_template('miapp/index.html')
    context = {
    }
    return HttpResponse(template.render(context, request))


def predict(request):
    template = loader.get_template('miapp/auto.html')
    grupo=int(request.POST.get("grupo"))
    miembro=int(request.POST.get("miembro"))
    cryo= bool(request.POST.get("cryo"))
    deck=request.POST.get("deck")
    B=C=D=E=F=G=T=TRAPP=PSO=EUROPA=MARS=0
    if deck=='B':
        B=1
    elif deck=='C':
        C=1
    elif deck=='D':
        D=1
    elif deck=='E':
        E=1
    elif deck=='F':
        F=1
    elif deck=='G':
        G=1
    elif deck=='T':
        T=1
    room_num=int(request.POST.get("room_num"))
    edad=int(request.POST.get("edad"))
    vip= bool(request.POST.get("vip"))
    room_serv=float(request.POST.get("room_serv"))
    food_court=float(request.POST.get("food_court"))
    shopping=float(request.POST.get("shopping"))
    spa=float(request.POST.get("spa"))
    vrd=float(request.POST.get("vrdeck"))
    gastos=room_serv+food_court+shopping+spa+vrd
    dest=request.POST.get("destination")
    if dest=='TRAPPIST-1e':
        TRAPP=1
    elif dest=='PSO J318.5-22':
        PSO=1
    hp=request.POST.get("home_planet")
    if hp=='Europa':
        EUROPA=1
    elif dest=='Mars':
        MARS=1
    persona = Persona(grupo=grupo,
                      miembro=miembro,
                      cryo= cryo,
                      room_num=room_num,
                      edad=edad,
                      vip= vip,
                      room_serv=room_serv,
                      food_court=food_court,
                      shopping=shopping,
                      spa=spa,
                      vrd=vrd,
                      gastos=gastos,
                      B=B,
                      C=C,
                      D=D,
                      E=E,
                      F=F,
                      G=G,
                      T=T,
                      PSO=PSO,
                      TRAPP=TRAPP,
                      EUROPA=EUROPA,
                      MARS=MARS)
    persona.save()
    personas=Persona.objects.all()
    modelo=pickle.load(open('modelo_def.sav', 'rb'))
    df = pd.DataFrame([[grupo,miembro,room_num,edad,vip,room_serv,food_court,shopping,spa,vrd,gastos,B,C,D,E,F,G,T,PSO,TRAPP,EUROPA,MARS]], 
                        columns=['grupo', 'id', 'CryoSleep', 'room_num', 'Age', 'VIP', 'RoomService',
                                 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'gastos', 'B', 'C', 'D',
                                 'E', 'F', 'G', 'T', 'PSO J318.5-22', 'TRAPPIST-1e', 'Europa', 'Mars'])
    prediccion=modelo.predict_proba(df)[:,1]
    prediccion=prediccion>=0.5
    ultimo=personas.last()
    ultimo.Transported=prediccion
    context = {
        'prediccion':prediccion
    }
    return HttpResponse(template.render(context, request))

